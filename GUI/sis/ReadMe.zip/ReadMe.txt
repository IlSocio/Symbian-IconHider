IconHider is a little utility to hide icons from the men� of your Symbian smartphone. Nothing more, nothing less. :)
It is also possible to hide IconHider's icon itself.
In that case, in order to access again to IconHider you'll need to dial a personal code and IconHider will immediately appear on the screen.

The TRIAL version is free of charge, but it can hide only 1 icon and you'll not be able to change the default personal code *0000*
The FULL version can hide up to 20 icons and you'll be able to set you own personal code as you wish.
